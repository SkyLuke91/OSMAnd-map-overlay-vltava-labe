# -*- coding: utf-8 -*-
"""
Vltava + Labe IENC/S-57 -> transparent MBTiles -> OsmAnd .sqlitedb

Spouštěj uvnitř QGIS Python Console:
    exec(open(r"C:\\...\\build_vltava_labe.py", encoding="utf-8").read())

QGIS 3.34+ / 3.44+.
"""
from pathlib import Path
import os, sys, math, sqlite3, shutil, traceback
from osgeo import ogr

from qgis.core import (
    QgsProject, QgsVectorLayer, QgsSymbol, QgsLineSymbol, QgsFillSymbol,
    QgsMarkerSymbol, QgsSingleSymbolRenderer, QgsPalLayerSettings,
    QgsTextFormat, QgsVectorLayerSimpleLabeling, QgsProperty,
    QgsCoordinateReferenceSystem, QgsCoordinateTransformContext,
    QgsWkbTypes
)
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtCore import QSize
import processing

# =========================
# USER SETTINGS
# =========================

# Put all official SPS Inland ENC .000 files here.
INPUT_DIR = Path.home() / "Vltava_Labe_OsmAnd" / "input"

# Output directory.
OUTPUT_DIR = Path.home() / "Vltava_Labe_OsmAnd" / "output"

MIN_ZOOM = 10
MAX_ZOOM = 18

# Transparent raster overlay.
# Do NOT change to opaque unless you intentionally want the chart background.
BACKGROUND = "0,0,0,0"

# Only navigation-relevant S-57 layers are included.
# Prefix matching is intentional because S-57 uses families such as BOY*.
PREFIXES = (
    "SOUNDG", "DEPCNT",
    "BOY", "BCN",
    "LIGHTS", "DAYMAR",
    "FAIRWY", "NAVLNE",
    "ACHARE", "HRBPRT", "PRCARE",
    "MORFAC", "MORGNL",
    "BRIDGE",
    "OBSTRN", "WRECKS",
    "RESARE", "DRGARE",
)

# =========================
# HELPERS
# =========================

def log(msg):
    print("[VLTAVA-LABE] " + str(msg))

def find_s57_cells(folder):
    files = sorted(folder.rglob("*.000"))
    if not files:
        raise RuntimeError(
            "V INPUT_DIR nebyl nalezen žádný *.000 soubor. "
            "Stáhni oficiální IENC/S-57 buňky z Geoportálu SPS."
        )
    return files

def list_s57_layers(cell):
    ds = ogr.Open(str(cell), 0)
    if ds is None:
        log("Nelze otevřít S-57: " + str(cell))
        return []
    names = []
    for i in range(ds.GetLayerCount()):
        lyr = ds.GetLayer(i)
        if lyr:
            names.append(lyr.GetName())
    ds = None
    return names

def wanted(layer_name):
    u = layer_name.upper()
    return any(u.startswith(p) for p in PREFIXES)

def make_renderer(layer_name, geom_type):
    u = layer_name.upper()

    # Lines
    if geom_type == QgsWkbTypes.LineGeometry:
        width = 0.35
        if u.startswith("DEPCNT"):
            width = 0.30
            color = QColor("#2878b5")
        elif u.startswith("FAIRWY") or u.startswith("NAVLNE"):
            width = 0.55
            color = QColor("#004f9e")
        else:
            color = QColor("#3d79a8")
        sym = QgsLineSymbol.createSimple({
            "color": color.name(),
            "width": str(width),
            "line_style": "solid"
        })
        return QgsSingleSymbolRenderer(sym)

    # Polygons: deliberately transparent fill.
    if geom_type == QgsWkbTypes.PolygonGeometry:
        if u.startswith("ACHARE"):
            outline = QColor("#b06a00")
        elif u.startswith("DRGARE"):
            outline = QColor("#4a79a8")
        elif u.startswith("RESARE"):
            outline = QColor("#9a5a5a")
        else:
            outline = QColor("#6b6b6b")
        sym = QgsFillSymbol.createSimple({
            "color": "0,0,0,0",
            "outline_color": outline.name(),
            "outline_width": "0.45"
        })
        return QgsSingleSymbolRenderer(sym)

    # Points
    color = QColor("#004f9e")
    size = 2.2
    shape = "circle"

    if u.startswith("SOUNDG"):
        color = QColor("#155f9c")
        size = 1.2
    elif u.startswith("BOY"):
        color = QColor("#d38b00")
        size = 3.0
    elif u.startswith("BCN"):
        color = QColor("#c24a24")
        size = 3.0
    elif u.startswith("LIGHTS"):
        color = QColor("#d8a300")
        size = 2.6
    elif u.startswith("DAYMAR"):
        color = QColor("#7d3c98")
        size = 2.6
    elif u.startswith("OBSTRN") or u.startswith("WRECKS"):
        color = QColor("#7a3d3d")
        size = 2.7

    sym = QgsMarkerSymbol.createSimple({
        "name": shape,
        "color": color.name(),
        "size": str(size),
        "outline_color": color.name()
    })
    return QgsSingleSymbolRenderer(sym)

def add_depth_labels(layer):
    fields = {f.name().upper(): f.name() for f in layer.fields()}
    # Common S-57 field for sounding value is VALSOU.
    fld = fields.get("VALSOU")
    if not fld:
        return

    pal = QgsPalLayerSettings()
    pal.fieldName = fld
    pal.isExpression = False
    pal.placement = QgsPalLayerSettings.OverPoint

    tf = QgsTextFormat()
    tf.setFont(QFont("Arial", 7))
    tf.setSize(7)
    tf.setColor(QColor("#155f9c"))
    pal.setFormat(tf)

    # Small white buffer improves readability over map details.
    try:
        buf = tf.buffer()
        buf.setEnabled(True)
        buf.setSize(0.6)
        buf.setColor(QColor(255,255,255,220))
        tf.setBuffer(buf)
        pal.setFormat(tf)
    except Exception:
        pass

    layer.setLabelsEnabled(True)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))

def add_name_labels(layer):
    fields = {f.name().upper(): f.name() for f in layer.fields()}
    fld = None
    for candidate in ("OBJNAM", "NOBJNM", "CATNAM"):
        if candidate in fields:
            fld = fields[candidate]
            break
    if not fld:
        return

    pal = QgsPalLayerSettings()
    pal.fieldName = fld
    pal.placement = QgsPalLayerSettings.Line if layer.geometryType() == QgsWkbTypes.LineGeometry else QgsPalLayerSettings.OverPoint
    tf = QgsTextFormat()
    tf.setFont(QFont("Arial", 7))
    tf.setSize(7)
    tf.setColor(QColor("#174b73"))
    pal.setFormat(tf)
    layer.setLabelsEnabled(True)
    layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))

def add_layer(path, layer_name, project):
    uri = f"{path}|layername={layer_name}"
    display = f"{path.stem} — {layer_name}"
    layer = QgsVectorLayer(uri, display, "ogr")
    if not layer.isValid():
        log("SKIP – QGIS nedokázal načíst " + uri)
        return None

    layer.setCrs(QgsCoordinateReferenceSystem("EPSG:4326"))
    layer.setRenderer(make_renderer(layer_name, layer.geometryType()))

    u = layer_name.upper()
    if u.startswith("SOUNDG"):
        add_depth_labels(layer)
    elif u.startswith(("BOY", "BCN", "ACHARE", "HRBPRT", "PRCARE", "MORFAC", "OBSTRN", "WRECKS")):
        add_name_labels(layer)

    # Hide layers outside useful scale ranges.
    if u.startswith("SOUNDG") or u.startswith(("BOY", "BCN", "LIGHTS", "DAYMAR")):
        layer.setMinimumScale(120000)
        layer.setMaximumScale(0)
    elif u.startswith(("DEPCNT", "FAIRWY", "NAVLNE")):
        layer.setMinimumScale(500000)
        layer.setMaximumScale(0)

    project.addMapLayer(layer, False)
    return layer

def convert_mbtiles_to_osmand(mbtiles, output, minz, maxz):
    log("Převádím MBTiles -> OsmAnd SQLite")
    src = sqlite3.connect(str(mbtiles))
    dst = sqlite3.connect(str(output))

    dst.executescript("""
    PRAGMA journal_mode=OFF;
    PRAGMA synchronous=OFF;
    DROP TABLE IF EXISTS info;
    DROP TABLE IF EXISTS tiles;
    CREATE TABLE info (
        tilenumbering TEXT,
        minzoom INTEGER,
        maxzoom INTEGER,
        title TEXT,
        url TEXT,
        randoms TEXT,
        ellipsoid TEXT,
        inverted_y TEXT,
        referer TEXT,
        useragent TEXT,
        timecolumn TEXT,
        expireminutes TEXT,
        tilesize INTEGER
    );
    CREATE TABLE tiles (
        x INTEGER,
        y INTEGER,
        z INTEGER,
        s INTEGER DEFAULT 0,
        image BLOB,
        PRIMARY KEY (x,y,z,s)
    );
    """)
    dst.execute(
        "INSERT INTO info VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        ("simple", minz, maxz, "Vltava + Labe — Inland ENC overlay",
         None, None, "0", "0", None, None, "no", None, 256)
    )

    # QGIS/MBTiles follows the standard MBTiles/TMS convention for tile_row.
    # OsmAnd simple numbering expects XYZ y.
    cols = [r[1] for r in src.execute("PRAGMA table_info(tiles)").fetchall()]
    if {"zoom_level", "tile_column", "tile_row", "tile_data"}.issubset(set(cols)):
        rows = src.execute(
            "SELECT zoom_level,tile_column,tile_row,tile_data FROM tiles"
        )
        n = 0
        for z, x, y_tms, blob in rows:
            y_xyz = (1 << int(z)) - 1 - int(y_tms)
            dst.execute(
                "INSERT OR REPLACE INTO tiles(x,y,z,s,image) VALUES(?,?,?,?,?)",
                (int(x), y_xyz, int(z), 0, blob)
            )
            n += 1
    else:
        raise RuntimeError(
            "Neznámá struktura MBTiles. Očekávám standardní tabulku tiles "
            "(zoom_level,tile_column,tile_row,tile_data)."
        )

    dst.execute("CREATE INDEX IF NOT EXISTS idx_tiles_zxy ON tiles(z,x,y)")
    dst.commit()
    src.close()
    dst.close()
    log(f"OsmAnd SQLite hotova: {output} ({n} dlaždic)")

def run():
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    cells = find_s57_cells(INPUT_DIR)
    log(f"Nalezeno S-57 buněk: {len(cells)}")

    project = QgsProject.instance()
    project.clear()
    project.setCrs(QgsCoordinateReferenceSystem("EPSG:3857"))

    added = 0
    seen = set()

    for cell in cells:
        for lname in list_s57_layers(cell):
            if not wanted(lname):
                continue
            # Do not deduplicate across cells: neighboring cells can have
            # distinct geometries under the same S-57 object class.
            layer = add_layer(cell, lname, project)
            if layer:
                added += 1

    if added == 0:
        raise RuntimeError(
            "Nenalezena žádná podporovaná navigační S-57 vrstva. "
            "Zkontroluj, že *.000 jsou skutečné Inland ENC buňky."
        )

    # QGIS renders XYZ in the project CRS; transform all loaded layers on the fly.
    qgz = OUTPUT_DIR / "Vltava_Labe_nav.qgz"
    project.write(str(qgz))
    log(f"QGIS projekt uložen: {qgz}")

    mbtiles = OUTPUT_DIR / "Vltava_Labe.mbtiles"
    if mbtiles.exists():
        mbtiles.unlink()

    # Use the extent of all loaded layers.
    extent = None
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer):
            continue
        e = lyr.extent()
        if e.isEmpty():
            continue
        if extent is None:
            extent = e
        else:
            extent.combineExtentWith(e)

    if extent is None or extent.isEmpty():
        raise RuntimeError("Nelze určit rozsah mapy.")

    # The S-57 layers are normally WGS84; QGIS project is EPSG:3857.
    # Processing receives the project extent in project CRS.
    params = {
        "EXTENT": extent,
        "ZOOM_MIN": MIN_ZOOM,
        "ZOOM_MAX": MAX_ZOOM,
        "DPI": 96,
        "BACKGROUND_COLOR": BACKGROUND,
        "TILE_FORMAT": 0,   # PNG, preserves alpha
        "QUALITY": 75,
        "METATILESIZE": 4,
        "ANTIALIAS": True,
        "OUTPUT_FILE": str(mbtiles),
    }

    log(f"Generuji MBTiles z{MIN_ZOOM}–z{MAX_ZOOM} …")
    processing.run("native:tilesxyzmbtiles", params)

    if not mbtiles.exists():
        raise RuntimeError("QGIS nevytvořil MBTiles.")

    sqlitedb = OUTPUT_DIR / "Vltava_Labe.sqlitedb"
    if sqlitedb.exists():
        sqlitedb.unlink()

    convert_mbtiles_to_osmand(mbtiles, sqlitedb, MIN_ZOOM, MAX_ZOOM)

    log("")
    log("HOTOVO")
    log("QGIS projekt: " + str(qgz))
    log("MBTiles:      " + str(mbtiles))
    log("OsmAnd:       " + str(sqlitedb))
    log("")
    log("Zkopíruj Vltava_Labe.sqlitedb do složky tiles v datovém adresáři OsmAnd.")
    log("V OsmAndu: Konfigurovat mapu -> Overlay mapa -> Vltava_Labe.")
    log("")

try:
    run()
except Exception as e:
    log("CHYBA: " + str(e))
    traceback.print_exc()
    raise
