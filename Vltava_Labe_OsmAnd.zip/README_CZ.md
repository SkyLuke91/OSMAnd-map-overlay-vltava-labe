# Vltava + Labe → OsmAnd overlay

Tento balíček připravuje transparentní navigační overlay z českých Inland ENC/S-57
souborů (`*.000`) pro použití v OsmAndu.

## Co potřebuješ

- QGIS 3.34+ (doporučeně aktuální LTR/3.44+)
- GDAL/OGR s podporou S-57 (součást běžné instalace QGIS)
- oficiální české IENC/S-57 buňky (`*.000`) stažené z Geoportálu SPS:
  https://geoportal.plavebniurad.cz/web/NavigationMap/InlandECDIS
- OsmAnd (Android je nejjednodušší cíl)

## Výstup

Skript vytvoří:

- `output/Vltava_Labe_nav.gpkg` – mezidata
- `output/Vltava_Labe_nav.qgz` – QGIS projekt se styly
- `output/Vltava_Labe.mbtiles` – průhledné XYZ/MBTiles
- `output/Vltava_Labe.sqlitedb` – přímo použitelný OsmAnd overlay

## Postup

1. Nainstaluj QGIS.
2. Z Geoportálu SPS stáhni všechny relevantní `.000` buňky pro Vltavu a Labe,
   které chceš mít offline. Je bezpečnější vzít všechny buňky pokrývající požadovaný úsek.
3. Rozbal je do `input/`.
4. Otevři QGIS → Plugins → Python Console.
5. Uprav v `build_vltava_labe.py` pouze `INPUT_DIR` (pokud je potřeba).
6. V Python Console spusť:

```python
exec(open(r"C:\cesta\Vltava_Labe_OsmAnd\build_vltava_labe.py", encoding="utf-8").read())
```

Na macOS/Linux uprav cestu podle umístění balíčku.

Skript vytvoří MBTiles a následně vlastní OsmAnd SQLite. Pro MBTiles používá
QGIS Processing `native:tilesxyzmbtiles`, který renderuje aktuální QGIS projekt
do XYZ/MBTiles s transparentním pozadím.

## Doporučené zoomy

Výchozí nastavení je `10–18`.

- z10–12: přehled
- z13–15: plavební objekty a hlavní značení
- z16–18: detailní hloubky a bóje

Pokud je výsledný soubor příliš velký, sniž `MAX_ZOOM` na 17.

## Co se zobrazí

Skript se snaží zachovat především navigační vrstvy:

- SOUNDG – hloubkové body
- DEPCNT – hloubnice
- BOY* / BCN* – bóje a znaky
- LIGHTS / DAYMAR – světla a denní znaky
- FAIRWY / NAVLNE – plavební dráha a navigační linie
- ACHARE – kotviště
- HRBPRT / PRCARE / MORGNL – přístavní objekty podle toho, co konkrétní ENC obsahuje
- MORFAC – mola a pobřežní zařízení
- BRIDGE – mosty
- OBSTRN / WRECKS – překážky a vraky
- RESARE / DRGARE – relevantní omezení/pásma, pokud jsou v buňce

S-57 názvy se mohou mezi buňkami lišit; skript proto vrstvu nejdříve
automaticky detekuje.

## OsmAnd

Oficiální formát SQLite používá tabulky `info` a `tiles`; tento skript zapisuje
`tilenumbering='simple'`, což je důležité pro standardní XYZ zoomy.

Po vytvoření `Vltava_Labe.sqlitedb`:

- zkopíruj soubor do složky `tiles` v datovém adresáři OsmAnd,
- v OsmAndu otevři Konfigurovat mapu → Overlay mapa,
- vyber `Vltava_Labe_nav`,
- nastav průhlednost podle potřeby.

Pokud Android soubor nepřijme přímým kopírováním, otevři `.sqlitedb` přes Sdílet/Otevřít v…
nebo použij import místních map podle verze OsmAndu.

## Důležitá bezpečnostní poznámka

Tento overlay je vizualizační pomůcka. Nejde o náhradu aktuálního Inland ECDIS
pro navigaci plavidla. Hloubky v ENC jsou vztažené k příslušným referenčním
podmínkám a mohou se změnit. Před plavbou používej aktuální oficiální navigační
informace a plavební omezení.

## Licence / zdroj

Data musíš stahovat z oficiálního Geoportálu SPS a respektovat jeho podmínky
užití. Tento balíček neobsahuje kopie ENC dat.
